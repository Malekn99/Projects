/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hangman;

import java.io.Serializable;
import java.util.List;

/**
 *
 * @author malek
 */
public class GameState implements Serializable {

    private String difficulty;
    private String wordToGuess;
    private int allowedGuess;
    private int remainingGuess;
    private List<Character> guessedLetters;
    private String currentState;
//Setters and getters
    public String getDifficulty() {
        return difficulty;
    }

    public void setDifficulty(String difficulty) {
        this.difficulty = difficulty;
    }

    public String getWordToGuess() {
        return wordToGuess;
    }

    public void setWordToGuess(String wordToGuess) {
        this.wordToGuess = wordToGuess;
    }

    public int getAllowedGuess() {
        return allowedGuess;
    }

    public void setAllowedGuess(int allowedGuess) {
        this.allowedGuess = allowedGuess;
    }

    public int getRemainingGuess() {
        return remainingGuess;
    }

    public void setRemainingGuess(int remainingGuess) {
        this.remainingGuess = remainingGuess;
    }

    public List<Character> getGuessedLetters() {
        return guessedLetters;
    }

    public void setGuessedLetters(List<Character> guessedLetters) {
        this.guessedLetters = guessedLetters;
    }

    public String getCurrentState() {
        return currentState;
    }

    public void setCurrentState(String currentState) {
        this.currentState = currentState;
    }

}
