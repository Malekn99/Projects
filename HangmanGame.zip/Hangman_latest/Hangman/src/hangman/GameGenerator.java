/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hangman;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author malek
 */
public class GameGenerator {
//Difficulty levels
    GameStore easyStore = null;
    GameStore mediumStore = null;
    GameStore hardStore = null;

    public void readFileAndPrepareGame(String fileName) throws IOException {
        try {
            List<String> readAllLines = Files.readAllLines(Paths.get(fileName));
            System.out.println("Total number of words :" + readAllLines.size());
            prepareGameStore(readAllLines);
        } catch (IOException ex) {
            Logger.getLogger(GameGenerator.class.getName()).log(Level.SEVERE, null, ex);
            throw ex;
        }
    }

    public void prepareGameStore(List<String> allWords) {
        List<String> easyWords = new ArrayList<>();
        List<String> mediumWords = new ArrayList<>();
        List<String> hardWords = new ArrayList<>();

        for (String s : allWords) {
            switch (s.length()) {
                case 10:
                    easyWords.add(s);
                    break;
                case 8:
                    mediumWords.add(s);
                    break;
                case 6:
                    hardWords.add(s);
                    break;
            }
        }

        easyStore = new GameStore(easyWords, 10, "easy");
        mediumStore = new GameStore(mediumWords, 7, "medium");
        hardStore = new GameStore(hardWords, 4, "hard");
    }

    public GameState getGame(String difficulty) {
        switch (difficulty) {
            case "easy":
                return easyStore.getGame();               
            case "medium":
                return mediumStore.getGame();
            case "hard":
                return hardStore.getGame();

        }
        return null;
    }
}
