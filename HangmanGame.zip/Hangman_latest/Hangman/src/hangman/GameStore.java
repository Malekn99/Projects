/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hangman;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 *
 * @author malek
 */
public class GameStore {
 
    String difficulty;
    List<String> words;
    int allowedGuess;
    
    
    public GameStore(List<String> words, int guess, String difficulty){
        this.words = words;
        this.allowedGuess = guess;
        this.difficulty = difficulty;        
    }
    //Get game
    public GameState getGame(){
        Random random = new Random();
        int questionId = random.nextInt(words.size());
        
        String word = words.get(questionId);
        
        GameState game = new GameState();
        game.setAllowedGuess(this.allowedGuess);
        StringBuilder sb = new StringBuilder();
        for(int i= 0; i < word.length();i++){
            sb.append("_");
        }
        game.setCurrentState(sb.toString());
        game.setDifficulty(this.difficulty);
        game.setGuessedLetters(new ArrayList<Character>());
        game.setRemainingGuess(this.allowedGuess);
        game.setWordToGuess(word);
        
        return game;
    }
    
}
