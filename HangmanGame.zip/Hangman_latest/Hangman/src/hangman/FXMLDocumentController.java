/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hangman;

import java.io.DataInput;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Slider;
import javafx.scene.control.TextField;
import javafx.stage.FileChooser;

/**
 *
 * @author malek
 */
public class FXMLDocumentController implements Initializable {

    GameGenerator generator = new GameGenerator();

    @FXML
    private Label difficultyLevel;

    @FXML
    private Button generateGameButton;

    @FXML
    private Button saveBtn;

    @FXML
    private Button guessBtn;

    @FXML
    private Slider slider;

    @FXML
    private Button loadBtn;

    @FXML
    private Button giveUpBtn;

    @FXML
    private Label gameState;

    @FXML
    private Label remainingGuess;

    @FXML
    private Label lettersGuessed;

    @FXML
    private TextField guessText;

    private GameState game = null;

    @FXML
    private Label errorLabel;

    @FXML
    private Label gameStatus;

    @FXML
    //Generates game
    private void handleGenerateGameAction(ActionEvent event) {
        System.out.println(difficultyLevel);
        game = generator.getGame(difficultyLevel.getText());
        if (game != null) {

            System.out.println(game.getWordToGuess());
            generateGameButton.setDisable(true);
            gameState.setDisable(false);
            updateLabels();
            saveBtn.setVisible(true);
            guessBtn.setVisible(true);
            giveUpBtn.setVisible(true);
        }
    }
//Updates labels
    public void updateLabels() {
        gameState.setText(game.getCurrentState());
        remainingGuess.setText(String.valueOf(game.getRemainingGuess()));
        List<Character> guessedLetters = game.getGuessedLetters();

        if (guessedLetters != null && guessedLetters.size() > 0) {
            StringBuilder sb = new StringBuilder();
            for (Character c : guessedLetters) {
                sb.append(c).append(", ");
            }
            lettersGuessed.setText(sb.toString());
        }
        
        
    }
//Guess button action
    public void handleGuessAction(ActionEvent action) {
        errorLabel.setText("");
        String text = guessText.getText();
        if (text.length() != 1) {
            errorLabel.setText("Only one letter guess is accepted.");
        } else {

            char guess = text.charAt(0);
            List<Character> guessedLetters = game.getGuessedLetters();
            if (guessedLetters.contains(guess)) {
                errorLabel.setText("You have already guessed this letter.");
            } else {
                String wordToGuess = game.getWordToGuess();
                guessedLetters.add(guess);
                StringBuilder sb = new StringBuilder(game.getCurrentState());
                if (wordToGuess.contains(guess + "")) {
                    for (int i = 0; i < wordToGuess.length(); i++) {
                        if (wordToGuess.charAt(i) == guess) {
                            sb.replace(i, i + 1, wordToGuess.charAt(i) + "");
                        }
                    }

                    game.setCurrentState(sb.toString());

                } else {
                    int rg = game.getRemainingGuess();
                    game.setRemainingGuess(rg - 1);
                }
                updateLabels();

                if (game.getCurrentState().equals(game.getWordToGuess())) {
                    gameStatus.setText("You won!");
                    guessBtn.setVisible(false);
                    giveUpBtn.setVisible(false);
                } else if (game.getRemainingGuess() == 0 && !game.getCurrentState().equalsIgnoreCase(game.getWordToGuess())) {
                    gameStatus.setText("You lost! Word was");
                    gameState.setText(game.getWordToGuess());
                    disableGameElements();
                }

            }
            guessText.clear();
        }
    }

    @FXML
    //Save button action
    public void handleSaveAction(ActionEvent action) {
        String fileName = game.getDifficulty() + "_" + System.currentTimeMillis();
        try {
            FileOutputStream fos = new FileOutputStream(new File(fileName));
            ObjectOutputStream oos = new ObjectOutputStream(fos);
            oos.writeObject(game);
        } catch (FileNotFoundException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @FXML
    //Load button action
    public void handleLoadAction(ActionEvent action) {

        FileChooser fileChooser = new FileChooser();
        File selectedFile = fileChooser.showOpenDialog(null);
        if (selectedFile != null) {
            try {
                FileInputStream fis = new FileInputStream(selectedFile);
                ObjectInputStream ois = new ObjectInputStream(fis);
               game =  (GameState) ois.readObject();
               updateLabels();
               if(game.getDifficulty().equals("easy")){
                    slider.setValue(1);
               }else if(game.getDifficulty().equals("medium")){
                    slider.setValue(2);
               }else{
                    slider.setValue(3);
               }
              
            } catch (FileNotFoundException ex) {
                Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
            } catch (IOException ex) {
                Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
            }
            
        } else {
           System.out.println("File selection cancelled.");

        }

    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {

        try {
            generator.readFileAndPrepareGame("hangmanWords.txt");
        } catch (IOException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        }

        slider.valueProperty().addListener((observable, oldValue, newValue) -> {

            if (newValue.intValue() == 1) {
                difficultyLevel.setText("easy");
            } else if (newValue.intValue() == 2) {
                difficultyLevel.setText("medium");
            } else {
                difficultyLevel.setText("hard");
            }

        });
    }

    private void disableGameElements() {
        saveBtn.setVisible(false);
        generateGameButton.setDisable(false);
        guessBtn.setVisible(false);
        giveUpBtn.setVisible(false);
        lettersGuessed.setText("");

    }

    public void giveUpAction(ActionEvent event) {
        gameState.setText(game.getWordToGuess());
        disableGameElements();
    }

}
